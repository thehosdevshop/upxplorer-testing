const cron = require("node-cron");
const util = require("util");
const mysql = require("mysql");

const pool = mysql.createPool({
    host: 'mysql-161810-0.cloudclusters.net',
    user: 'admin',
    password: 'iKl3KA5b',
    database: 'upxplorer',
    port: 19878
});

const queryAsync = util.promisify(pool.query).bind(pool);


async function getMinutes(input_time_one, input_time_two) {
    return (input_time_one.getTime() - input_time_two.getTime()) / 60000
}

async function getCurrentTimeUTC() {
    // Get current time in UTC
    var current_time_utc = new Date();
    var utcYear = current_time_utc.getUTCFullYear();
    var utcMonth = current_time_utc.getUTCMonth();
    var utcDay = current_time_utc.getUTCDate();
    var utcHour = current_time_utc.getUTCHours();
    var utcMinute = current_time_utc.getUTCMinutes();
    var utcSecond = current_time_utc.getUTCSeconds();
    var utcMillisecond = current_time_utc.getUTCMilliseconds();

    return new Date(Date.UTC(utcYear, utcMonth, utcDay, utcHour, utcMinute, utcSecond, utcMillisecond));
}

async function addHoursToTimestamp(hours) {
    // Current time in UTC
    var current_time_utc = await getCurrentTimeUTC();

    // Add hours to the current time
    var new_time_utc = new Date(current_time_utc.getTime() + hours * 60 * 60 * 1000);

    // Remove the 'Z' at the end
    var timestamp = new_time_utc.toISOString().slice(0, -1);

    // Return the new timestamp
    return timestamp;
}

async function updateBuildStatus(offset) {
    try {
        let check_time = new Date();
        check_time.setMinutes(check_time.getMinutes() - 60);
        let query =
            "SELECT * FROM build_activities_all WHERE status = ? order by build_start_time desc limit 3000 offset ?";
        const response = await queryAsync(query, ["processing", offset]);

        if (response.length > 0) {
            let remainingSparkHours, totalSparkStaked;
            for (let i = 0; i < response.length; i++) {
                let current_time = new Date();
                const requiredSparkHours = response[i]["required_spark_hours"]
                let getAllStakequery = "SELECT * FROM user_spark_activity WHERE build_id =?";
                const stakeArray = await queryAsync(getAllStakequery, response[i]["nft_id"]);
                let totalStakedHoursFound = 0;
                let totalUnstakedHoursFound = 0;
                let totalStaked = 0;
                let totalUnstaked = 0;
                for (let i = 0; i < stakeArray.length; i++) {
                    let stakedHours = ((current_time?.getTime() - stakeArray[i]?.start_time?.getTime()) / 3600000) * parseFloat(stakeArray[i].spark_amount);
                    if (stakeArray[i]?.type == 'stake') {
                        // console.log("stake", stakedHours)
                        totalStakedHoursFound = totalStakedHoursFound + stakedHours;
                        totalStaked = totalStaked + parseFloat(stakeArray[i].spark_amount)
                    }
                    else {
                        // console.log("unstake", stakedHours)
                        totalUnstakedHoursFound = totalUnstakedHoursFound + stakedHours;
                        totalUnstaked = totalUnstaked + parseFloat(stakeArray[i].spark_amount)
                    }
                }
                // console.log("Total Staked",totalStaked,"Total Unstaked", totalUnstaked ,"for", response[i]["nft_id"])
                remainingSparkHours = parseInt(requiredSparkHours) - (totalStakedHoursFound - totalUnstakedHoursFound)
                totalSparkStaked = totalStaked - totalUnstaked
                console.log("remainingSparkHours", remainingSparkHours, "spark_staked", totalSparkStaked, "for", response[i]["nft_id"])
                let update_time = new Date();
                let expected_complete_time = null
                if(totalSparkStaked > 0){
                    expected_complete_time = await addHoursToTimestamp(remainingSparkHours/totalSparkStaked)
                }
                if (remainingSparkHours <= 0) {
                    let updateBuildQuery = `UPDATE build_activities_all SET  updated_on = ?, status = ?, current_staked_spark = ?,remaining_spark_hours = ?, expected_complete_time = ? where nft_id = ?`;
                    await queryAsync(updateBuildQuery, [
                        update_time.toISOString().slice(0, -1),
                        "completed",
                        totalSparkStaked,
                        remainingSparkHours,
                        expected_complete_time,
                        response[i]["nft_id"],
                    ]);
                    console.log("COMPLETED: Updated build, remaining spark hours", remainingSparkHours, "spark_staked", totalSparkStaked, "for", response[i]["nft_id"])
                }
                else {
                    let updateBuildQuery = `UPDATE build_activities_all SET updated_on = ?, current_staked_spark = ?,remaining_spark_hours = ? , expected_complete_time = ? where nft_id = ?`;
                    await queryAsync(updateBuildQuery, [
                        update_time.toISOString().slice(0, -1),
                        totalSparkStaked,
                        remainingSparkHours,
                        expected_complete_time,
                        response[i]["nft_id"],
                    ]);
                    console.log("UPDATED TIME: Updated build, remaining spark hours", remainingSparkHours, "spark_staked", totalSparkStaked, "for", response[i]["nft_id"])
                }

            }
            return parseInt(response.length)
        }
        else if(response.length == 0){
            return 0
        }
    } catch (error) {
        console.log(error)
    }
}



async function main(){
    let offset = 0;
    let isMore = true;
    while(isMore) {
        const count = await updateBuildStatus(offset)
        offset = offset + count
        if(count == 0)
            isMore=false
    }
} 

 main()

    
