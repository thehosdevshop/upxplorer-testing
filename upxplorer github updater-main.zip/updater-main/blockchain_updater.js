const cron = require("node-cron");
const axios = require("axios");
const util = require("util");
const mysql = require("mysql");

// let currentPos = 4645424;
let currentPos = 5125149;

// const pool = mysql.createPool(process.env.JAWSDB_URL);
const pool = mysql.createPool({
    host: "mysql-161810-0.cloudclusters.net",
    user: "admin",
    password: "iKl3KA5b",
    database: "upxplorer",
    port: 19878
});


const queryAsync = util.promisify(pool.query).bind(pool);
let block_time = "";
cron.schedule("*/60 * * * * *", async () => {
    try {

        // Stake and build check
        const response = await fetchEosData(currentPos);
        const data = response.data;

        if (data && data.actions && data.actions.length > 0) {
            // Process data and update the database

            let counter = 0;
            let build_insert = 0
            let stake_insert = 0
            block_time = data.actions[0].block_time;
            for (const action of data["actions"]) {
                counter++;
                const actionName = action["action_trace"]["act"]["name"];
                const fullignoreName = [
                    "setcode",
                    "setabi",
                    "create",
                    "setutility",
                    "issue"
                ];
                if (fullignoreName.includes(actionName)) {
                    continue;
                }

                if (actionName === "transfer") {
                    const memo = action["action_trace"]["act"]["data"]["memo"];

                    if (memo === "") {
                        continue;
                    }
                    const parts = await memo.split(",");
                    if (
                        action["action_trace"]["act"]["data"]["quantity"].split(" ")[1] !==
                        "USPK"
                    ) {
                        console.log("Invalid action quantity");
                    }



                    if (parts[0] === "STAKE") {
                        const eosId = action["action_trace"]["act"]["data"]["from"];
                        const txn_id = action["action_trace"]["trx_id"];
                        const buildingId = parts[1].toString();
                        const amount =
                            action["action_trace"]["act"]["data"]["quantity"].split(" ")[0];
                        const time = action["action_trace"]["block_time"];

                        try {
                            let query = "SELECT * FROM build_activities_all WHERE nft_id =?";
                            const result = await queryAsync(query, [buildingId]);
                            if (result.length > 0) {

                                // insert into spark activity
                                let query = "SELECT * FROM user_spark_activity WHERE txn_id= ?";

                                const response = await queryAsync(query, [txn_id]);
                                if (response.length == 0) {
                                   
                                    if (new Date(result[0].build_start_time).getTime() < new Date(time).getTime()) {
                                        const insertStakeQuery =
                                            "INSERT INTO user_spark_activity (eos_id, spark_amount, start_time, build_id, type, txn_id) VALUES (?, ?, ?, ?, ?, ?)";
                                        await queryAsync(insertStakeQuery, [
                                            eosId,
                                            amount,
                                            time,
                                            buildingId,
                                            "stake",
                                            txn_id
                                        ]);
                                        stake_insert++;
                                        console.log(
                                            `created for ${buildingId} user spark activity, spark_amount: ${amount}, start_time: ${time}, eos_id: ${eosId}`
                                        );
                                    }
                                }
                            }
                        } catch (error) {
                            console.log("Error in STAKE event processing:", error);
                        }
                    } else if (parts[0] === "BUILD") {

                        const owner_eos_id = action["action_trace"]["act"]["data"]["from"];
                        const propertyId = parts[2];
                        const initial_staked_amount =
                            action["action_trace"]["act"]["data"]["quantity"].split(" ")[0];
                        const txn_id = action["action_trace"]["trx_id"];
                        const structureType = parts[9]; // this is the code word of property_type

                        const requiredSparkHours = parts[5];

                        const buildingId = parts[1].toString();

                        const time = action["action_trace"]["block_time"];

                        const maxStake = parts[7];

                        //   console.log("propertyId", parts[2]);
                        //   console.log("structureType", parts[9]);
                        //   console.log("requiredSparkHours", parts[5]);
                        //   console.log("buildingId", parts[1]);
                        //   console.log("time", action["action_trace"]["block_time"]); // start time
                        //   console.log("maxStake", parts[7] / 100);

                        try {
                            let query = "SELECT * FROM build_activities_all WHERE nft_id =?";
                            const result = await queryAsync(query, [buildingId]);
                            if (result.length == 0) {
                                // insert into build activities
                                const insertBuildQuery =
                                    "INSERT INTO build_activities_all (nft_id, required_spark_hours, property_id,owner_eos_id,max_stake, build_start_time, status, txn_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                                await queryAsync(insertBuildQuery, [
                                    buildingId,
                                    requiredSparkHours,
                                    propertyId,
                                    owner_eos_id,
                                    parseInt(maxStake) / 100,
                                    time,
                                    "processing",
                                    txn_id
                                ]);

                                console.log(
                                    `created for ${buildingId} build_activities_all, requiredSparkHours: ${requiredSparkHours}, build_start_time: ${time}, owner_eos_id: ${owner_eos_id}, property_id : ${propertyId}`
                                );

                                // insert into spark activity
                                const insertStakeQuery =
                                    "INSERT INTO user_spark_activity (eos_id, spark_amount, start_time, build_id, type, txn_id) VALUES (?, ?, ?, ?, ?, ?)";
                                await queryAsync(insertStakeQuery, [
                                    owner_eos_id,
                                    initial_staked_amount,
                                    time,
                                    buildingId,
                                    "stake", 
                                    txn_id
                                ]);
                                build_insert++;
                                console.log(
                                    `created for ${buildingId} user spark activity STAKE, spark_amount: ${initial_staked_amount}, start_time: ${time}, owner_eos_id: ${owner_eos_id}`
                                );
                            }
                            else {
                                if (!(result[0].txn_id == txn_id)) {

                                    let nftKey = "archive_" + time + "_" + result[0]["nft_id"]
                                    let updateBuildQuery = `UPDATE build_activities_all SET nft_id= ?, status = ? WHERE nft_id = ?`;
                                    await queryAsync(updateBuildQuery, [
                                        nftKey,
                                        "archived",
                                        result[0]["nft_id"]
                                    ]);
                                    console.log(
                                        `created for ${buildingId} user spark activity STAKE, spark_amount: ${initial_staked_amount}, start_time: ${time}, owner_eos_id: ${owner_eos_id}, Archived Old`
                                    );

                                    // insert into build activities
                                    const insertBuildQuery =
                                        "INSERT INTO build_activities_all (nft_id, required_spark_hours, property_id,owner_eos_id,max_stake, build_start_time, status, txn_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                                    await queryAsync(insertBuildQuery, [
                                        buildingId,
                                        requiredSparkHours,
                                        propertyId,
                                        owner_eos_id,
                                        parseInt(maxStake) / 100,
                                        time,
                                        "processing",
                                        txn_id
                                    ]);

                                    console.log(
                                        `created for ${buildingId} build_activities_all, requiredSparkHours: ${requiredSparkHours}, build_start_time: ${time}, owner_eos_id: ${owner_eos_id}, property_id : ${propertyId}`
                                    );

                                    // insert into spark activity
                                    const insertStakeQuery =
                                        "INSERT INTO user_spark_activity (eos_id, spark_amount, start_time, build_id, type, txn_id) VALUES (?, ?, ?, ?, ?,?)";
                                    await queryAsync(insertStakeQuery, [
                                        owner_eos_id,
                                        initial_staked_amount,
                                        time,
                                        buildingId,
                                        "stake",
                                        txn_id
                                    ]);
                                    build_insert++;
                                    console.log(
                                        `created for ${buildingId} user spark activity STAKE, spark_amount: ${initial_staked_amount}, start_time: ${time}, owner_eos_id: ${owner_eos_id}`
                                    );
                                }
                            }
                        } catch (error) {
                            console.error("Error in BUILD event processing:", error);
                        }
                    }
                }
            }

            console.log('Stake Build counter', counter)
            console.log('stake insert for pos', currentPos, "stake_insert", stake_insert)
            console.log('Build insert for pos', currentPos, "build_insert", build_insert)
        }
        currentPos += data.actions.length;
        console.log('currentPos', currentPos)

        // Unstake check
        const unstake_response = await fetchUnstakeEosData(block_time);
        const unstake_data = unstake_response.data;

        if (unstake_data && unstake_data.actions && unstake_data.actions.length > 0) {

            let counter = 0;
            let unstake_insert = 0

            for (const action of unstake_data["actions"]) {
                counter++;
                const actionName = action["act"]["name"];
                const fullignoreName = [
                    "setcode",
                    "setabi",
                    "create",
                    "setutility",
                    "issue"
                ];
                if (fullignoreName.includes(actionName)) {
                    continue;
                }

                if (actionName === "n512") {
                    const eosId = action["act"]["data"]["p51"];
                    const propertyId = action["act"]["data"]["p113"];
                    const amount =
                        action["act"]["data"]["p45"].split(" ")[0];
                    const time = action["timestamp"];
                    const txn_id = action["trx_id"];

                    // console.log("eosId", eosId);
                    // console.log("propertyId", propertyId);
                    // console.log("amount", amount);
                    // console.log("time", time); // current time

                    let query = "SELECT * FROM build_activities_all WHERE nft_id =?";
                    const result = await queryAsync(query, [propertyId]);
                    if (result.length > 0) {
                        let query = "SELECT * FROM user_spark_activity WHERE txn_id = ?";
                        const response = await queryAsync(query, [txn_id]);
                        if (response.length == 0) {
                            if (new Date(result[0].build_start_time).getTime() < new Date(time).getTime()) {
                            // insert into spark activity
                            unstake_insert++
                            const insertStakeQuery =
                                "INSERT INTO user_spark_activity (eos_id, spark_amount, start_time, build_id, type,txn_id ) VALUES (?, ?, ?, ?, ?,?)";
                            await queryAsync(insertStakeQuery, [
                                eosId,
                                amount,
                                time,
                                propertyId,
                                "unstake",
                                txn_id
                            ]);

                            console.log(
                                `created for ${propertyId} user spark activity UNSTAKE, spark_amount: ${amount}, start_time: ${time}, eos_id: ${eosId}, build_id: ${propertyId}`
                            );
                        }}
                    }
                }
            }
            console.log('UnStake counter', counter)
            console.log('unstake insert for time before', block_time, "unstake_insert", unstake_insert)
        }

        // Build destory check 
        const destory_response = await fetchDestoryedEosData(block_time);
        const destory_data = destory_response.data;

        if (destory_data && destory_data.actions && destory_data.actions.length > 0) {

            let counter = 0;
            let destory_insert = 0

            for (const action of destory_data["actions"]) {
                counter++;
                const actionName = action["act"]["name"];
                const fullignoreName = [
                    "setcode",
                    "setabi",
                    "create",
                    "setutility",
                    "issue"
                ];
                if (fullignoreName.includes(actionName)) {
                    continue;
                }

                if (actionName === "a32") {
                    const owner_eos_id = action["act"]["data"]["a54"];
                    const nft_id = action["act"]["data"]["p115"];
                    const time = action["timestamp"];
                    let query = "SELECT * FROM build_activities_all WHERE nft_id =?";
                    const txn_id = action["trx_id"];
                    const nft_result = await queryAsync(query, [nft_id]);
                    if(nft_result.length > 0){
                        if (new Date(nft_result[0].build_start_time).getTime() < new Date(time).getTime() ) {
                            if(!(nft_result[0].status == 'destroyed')){
                            let updateBuildQuery = `UPDATE build_activities_all SET   status = ? where nft_id = ?`;
                            await queryAsync(updateBuildQuery, [
                                "destroyed",
                                nft_id,
                            ]);
                            destory_insert++
                            console.log(
                                `Updated for ${nft_id} Destory,  destroy_start_time: ${time}, owner_eos_id: ${owner_eos_id}`
                            );
                    }
                }
                }
                }
            }
            console.log('Destory counter', counter)
            console.log('Destory insert for time before', block_time, "destory_insert", destory_insert)
        }

        // Build deposit check 
        const transfer_response = await fetchDepositEosData(block_time);
        const transfer_data = transfer_response.data;

        if (transfer_data && transfer_data.actions && transfer_data.actions.length > 0) {

            let counter = 0;
            let deposit_insert = 0

            for (const action of transfer_data["actions"]) {
                counter++;
                const actionName = action["act"]["name"];
                const fullignoreName = [
                    "setcode",
                    "setabi",
                    "create",
                    "setutility",
                    "issue"
                ];
                if (fullignoreName.includes(actionName)) {
                    continue;
                }

                if (actionName === "n111") {
                    const playerOne = action["act"]["data"]["p1"];
                    const playerTwo = action["act"]["data"]["p2"];
                    const amount =
                        action["act"]["data"]["p45"].split(" ")[0];
                    const time = action["timestamp"];
                    const txn_id = action["trx_id"];
                    const tax = action["act"]["data"]["p134"].split(" ")[0];
                    
                    // console.log("eosId", eosId);
                    // console.log("propertyId", propertyId);
                    // console.log("amount", amount);
                    // console.log("time", time); // current time
                    if (playerTwo == "t244kyn1cc2m"){
                        let query = "SELECT * FROM transactions WHERE transaction_id =?";
                        const trx_result = await queryAsync(query, [txn_id]);
                        if(trx_result.length == 0){
                            let query = "SELECT * FROM upland_data WHERE upland_eos_id =? and upland_auth_token is NOT NULL";
                            const db_result = await queryAsync(query, [playerOne]);
                            if(db_result.length > 0){
                                const insertDepositQuery =
                                "INSERT INTO transactions (transaction_id, initiated_by, upx_amount, type, source_wallet, destination_wallet, memo, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                                await queryAsync(insertDepositQuery, [
                                    txn_id,
                                    db_result[0].email_address,
                                    parseFloat(amount)+parseFloat(tax),
                                    "deposit",
                                    playerOne,
                                    playerTwo,
                                    "direct",
                                    "completed"
                                ]);
                                const walletUpdateQuery = "UPDATE wallet SET upx_balance = upx_balance + ? where email_address = ?"
                                await queryAsync(walletUpdateQuery, [
                                    parseFloat(amount)-parseFloat(tax),
                                    db_result[0].email_address
                                ]);
                                deposit_insert++;
                            }
                            
                        }
                    }
                }
            }
            console.log('deposit counter', counter)
            console.log('Deposit insert for time before', block_time, "deposit_insert", deposit_insert)
        }
    } catch (error) {
        console.error("Error in cron job:", error);
    }
});

function fetchEosData(pos) {
    return axios.post(`https://eos.greymass.com/v1/history/get_actions`, {
        account_name: "uspktokenacc",
        pos: pos.toString(),
        offset: "100"
    });
}
function fetchUnstakeEosData(block_time) {
    const url = `https://eos.hyperion.eosrio.io/v2/history/get_actions?account=playuplandme&filter=*%3An512&sort=desc&before=${block_time}&limit=50`
    return axios.get(url);
}

function fetchDepositEosData(block_time) {
    const url = `https://eos.hyperion.eosrio.io/v2/history/get_actions?account=playuplandme&filter=*%3An111&sort=desc&before=${block_time}&limit=100`
    return axios.get(url);
}

function fetchDestoryedEosData(block_time) {
    const url = `https://eos.hyperion.eosrio.io/v2/history/get_actions?account=playuplandme&filter=*%3Aa32&sort=desc&before=${block_time}&limit=50`
    return axios.get(url);
}
