const cron = require("node-cron");
const axios = require("axios");
const util = require("util");
const mysql = require("mysql");
const fs = require('fs');

// let currentPos = 4645424;
let currentPos = 752792576;

function loadLogsFromFile(filePath) {
    try {
        const data = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading logs file:', error);
        return [];
    }
}

function saveLogsToFile(filePath, logs) {
    // Convert logs array to JSON string
    const logsJson = JSON.stringify(logs, null, 2); // The third parameter (2) adds indentation for readability

    // Write JSON to the file
    fs.writeFileSync(filePath, logsJson);

    console.log(`Logs saved to ${filePath}`);
}

// const pool = mysql.createPool(process.env.JAWSDB_URL);
const pool = mysql.createPool({
    host: "mysql-161810-0.cloudclusters.net",
    user: "admin",
    password: "iKl3KA5b",
    database: "upxplorer",
    port: 19878
});


const queryAsync = util.promisify(pool.query).bind(pool);


// Specify the file path
const logsFilePath = './logs/blockchain_scraper.json';
const ErrorFilePath = './logs/errors.json';


// Load existing logs from the file
let existingErrors = loadLogsFromFile(ErrorFilePath);


function fetchEosData(pos) {
    return axios.post(`https://eos.greymass.com/v1/history/get_actions`, {
        account_name: "playuplandme",
        pos: pos.toString(),
        offset: "100"
    });
}

cron.schedule("*/7 * * * * *", async () => {
    try {
        let existingLogs = [];
        // Stake and build check
        const response = await fetchEosData(currentPos);
        const data = response.data;
        let counter = 0;
        if (data && data.actions && data.actions.length > 0) {
            const logData = {
                timestamp: new Date().toISOString(),
                action: `Checking for pos: ${currentPos}`
            };
            existingLogs.push(logData);
            // block_time = data.actions[0].block_time;
            for (const action of data["actions"]) {
                counter++;
                const actionName = action["action_trace"]["act"]["name"];
                // const fullignoreName = [
                //     "setcode",
                //     "setabi",
                //     "create",
                //     "setutility",
                //     "issue"
                // ];
                // if (fullignoreName.includes(actionName)) {
                //     continue;
                // }

                if (actionName === "transfer") {
                    const memo = action["action_trace"]["act"]["data"]["memo"];
                    let build_insert = 0
                    let stake_insert = 0

                    if (memo === "") {
                        continue;
                    }
                    const parts = await memo.split(",");
                    if (
                        action["action_trace"]["act"]["data"]["quantity"].split(" ")[1] !==
                        "USPK"
                    ) {
                        console.log("Invalid action quantity");
                    }



                    if (parts[0] === "STAKE") {
                        const eosId = action["action_trace"]["act"]["data"]["from"];
                        const txn_id = action["action_trace"]["trx_id"];
                        const buildingId = parts[1].toString();
                        const amount =
                            action["action_trace"]["act"]["data"]["quantity"].split(" ")[0];
                        const time = action["action_trace"]["block_time"];

                        try {
                            let query = "SELECT * FROM build_activities_all WHERE nft_id =?";
                            const result = await queryAsync(query, [buildingId]);
                            if (result.length > 0) {

                                // insert into spark activity
                                let query = "SELECT * FROM user_spark_activity WHERE txn_id= ?";

                                const response = await queryAsync(query, [txn_id]);
                                if (response.length == 0) {

                                    if (new Date(result[0].build_start_time).getTime() < new Date(time).getTime()) {
                                        const insertStakeQuery =
                                            "INSERT INTO user_spark_activity (eos_id, spark_amount, start_time, build_id, type, txn_id) VALUES (?, ?, ?, ?, ?, ?)";
                                        await queryAsync(insertStakeQuery, [
                                            eosId,
                                            amount,
                                            time,
                                            buildingId,
                                            "stake",
                                            txn_id
                                        ]);
                                        stake_insert++;
                                        const logData = {
                                            timestamp: new Date().toISOString(),
                                            action: `created for ${buildingId} user spark activity, spark_amount: ${amount}, start_time: ${time}, eos_id: ${eosId}`
                                        };
                                        existingLogs.push(logData);
                                        console.log(
                                            `created for ${buildingId} user spark activity, spark_amount: ${amount}, start_time: ${time}, eos_id: ${eosId}`
                                        );
                                    }
                                }
                            }
                        } catch (error) {
                            const logData = {
                                timestamp: new Date().toISOString(),
                                action: `Error in STAKE event processing: ${error}`
                            };
                            existingErrors.push(logData);
                            console.log("Error in STAKE event processing:", error);
                        }
                    } else if (parts[0] === "BUILD") {

                        const owner_eos_id = action["action_trace"]["act"]["data"]["from"];
                        const propertyId = parts[2];
                        const initial_staked_amount =
                            action["action_trace"]["act"]["data"]["quantity"].split(" ")[0];
                        const txn_id = action["action_trace"]["trx_id"];
                        const structureType = parts[9]; // this is the code word of property_type

                        const requiredSparkHours = parts[5];

                        const buildingId = parts[1].toString();

                        const time = action["action_trace"]["block_time"];

                        const maxStake = parts[7];


                        try {
                            let query = "SELECT * FROM build_activities_all WHERE nft_id =?";
                            const result = await queryAsync(query, [buildingId]);
                            if (result.length == 0) {
                                // insert into build activities
                                const insertBuildQuery =
                                    "INSERT INTO build_activities_all (nft_id, required_spark_hours, property_id,owner_eos_id,max_stake, build_start_time, status, txn_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                                await queryAsync(insertBuildQuery, [
                                    buildingId,
                                    requiredSparkHours,
                                    propertyId,
                                    owner_eos_id,
                                    parseInt(maxStake) / 100,
                                    time,
                                    "processing",
                                    txn_id
                                ]);

                                const logData = {
                                    timestamp: new Date().toISOString(),
                                    action: `created for ${buildingId} build_activities_all, requiredSparkHours: ${requiredSparkHours}, build_start_time: ${time}, owner_eos_id: ${owner_eos_id}, property_id : ${propertyId}`
                                };
                                existingLogs.push(logData);

                                console.log(
                                    `created for ${buildingId} build_activities_all, requiredSparkHours: ${requiredSparkHours}, build_start_time: ${time}, owner_eos_id: ${owner_eos_id}, property_id : ${propertyId}`
                                );

                                // insert into spark activity
                                const insertStakeQuery =
                                    "INSERT INTO user_spark_activity (eos_id, spark_amount, start_time, build_id, type, txn_id) VALUES (?, ?, ?, ?, ?, ?)";
                                await queryAsync(insertStakeQuery, [
                                    owner_eos_id,
                                    initial_staked_amount,
                                    time,
                                    buildingId,
                                    "stake",
                                    txn_id
                                ]);
                                build_insert++;
                                const logData2 = {
                                    timestamp: new Date().toISOString(),
                                    action: `created for ${buildingId} user spark activity STAKE, spark_amount: ${initial_staked_amount}, start_time: ${time}, owner_eos_id: ${owner_eos_id}`
                                };
                                existingLogs.push(logData2);
                                console.log(
                                    `created for ${buildingId} user spark activity STAKE, spark_amount: ${initial_staked_amount}, start_time: ${time}, owner_eos_id: ${owner_eos_id}`
                                );
                            }
                            else {
                                if (!(result[0].txn_id == txn_id)) {

                                    let nftKey = "archive_" + time + "_" + result[0]["nft_id"]
                                    let updateBuildQuery = `UPDATE build_activities_all SET nft_id= ?, status = ? WHERE nft_id = ?`;
                                    await queryAsync(updateBuildQuery, [
                                        nftKey,
                                        "archived",
                                        result[0]["nft_id"]
                                    ]);
                                    const logData = {
                                        timestamp: new Date().toISOString(),
                                        action: `created for ${buildingId} user spark activity STAKE, spark_amount: ${initial_staked_amount}, start_time: ${time}, owner_eos_id: ${owner_eos_id}, Archived Old`
                                    };
                                    existingLogs.push(logData);
                                    console.log(
                                        `created for ${buildingId} user spark activity STAKE, spark_amount: ${initial_staked_amount}, start_time: ${time}, owner_eos_id: ${owner_eos_id}, Archived Old`
                                    );

                                    // insert into build activities
                                    const insertBuildQuery =
                                        "INSERT INTO build_activities_all (nft_id, required_spark_hours, property_id,owner_eos_id,max_stake, build_start_time, status, txn_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                                    await queryAsync(insertBuildQuery, [
                                        buildingId,
                                        requiredSparkHours,
                                        propertyId,
                                        owner_eos_id,
                                        parseInt(maxStake) / 100,
                                        time,
                                        "processing",
                                        txn_id
                                    ]);
                                    const logData2 = {
                                        timestamp: new Date().toISOString(),
                                        action: `created for ${buildingId} build_activities_all, requiredSparkHours: ${requiredSparkHours}, build_start_time: ${time}, owner_eos_id: ${owner_eos_id}, property_id : ${propertyId}`
                                    };
                                    existingLogs.push(logData2);
                                    console.log(
                                        `created for ${buildingId} build_activities_all, requiredSparkHours: ${requiredSparkHours}, build_start_time: ${time}, owner_eos_id: ${owner_eos_id}, property_id : ${propertyId}`
                                    );

                                    // insert into spark activity
                                    const insertStakeQuery =
                                        "INSERT INTO user_spark_activity (eos_id, spark_amount, start_time, build_id, type, txn_id) VALUES (?, ?, ?, ?, ?,?)";
                                    await queryAsync(insertStakeQuery, [
                                        owner_eos_id,
                                        initial_staked_amount,
                                        time,
                                        buildingId,
                                        "stake",
                                        txn_id
                                    ]);
                                    build_insert++;
                                    const logData3 = {
                                        timestamp: new Date().toISOString(),
                                        action: `created for ${buildingId} user spark activity STAKE, spark_amount: ${initial_staked_amount}, start_time: ${time}, owner_eos_id: ${owner_eos_id}`
                                    };
                                    existingLogs.push(logData3);
                                    console.log(
                                        `created for ${buildingId} user spark activity STAKE, spark_amount: ${initial_staked_amount}, start_time: ${time}, owner_eos_id: ${owner_eos_id}`
                                    );
                                }
                            }
                        } catch (error) {
                            const logData = {
                                timestamp: new Date().toISOString(),
                                action: `Error in BUILD event processing: ${error}`
                            };
                            existingErrors.push(logData);
                            console.error("Error in BUILD event processing:", error);
                        }
                    }
                    console.log('stake insert for pos', currentPos, "stake_insert", stake_insert)
                    console.log('Build insert for pos', currentPos, "build_insert", build_insert)
                }

                else if (actionName === "n512") {

                    let unstake_insert = 0
                    try {
                        const eosId = action["action_trace"]["act"]["data"]["p51"];
                        const propertyId = action["action_trace"]["act"]["data"]["p113"];
                        const amount = action["action_trace"]["act"]["data"]["p45"].split(" ")[0];
                        const time = action["action_trace"]["block_time"];
                        const txn_id = action["action_trace"]["trx_id"];


                        let query = "SELECT * FROM build_activities_all WHERE nft_id =?";
                        const result = await queryAsync(query, [propertyId]);
                        if (result.length > 0) {
                            let query = "SELECT * FROM user_spark_activity WHERE txn_id = ?";
                            const response = await queryAsync(query, [txn_id]);
                            if (response.length == 0) {
                                if (new Date(result[0].build_start_time).getTime() < new Date(time).getTime()) {
                                    // insert into spark activity
                                    unstake_insert++
                                    const insertStakeQuery =
                                        "INSERT INTO user_spark_activity (eos_id, spark_amount, start_time, build_id, type,txn_id ) VALUES (?, ?, ?, ?, ?,?)";
                                    await queryAsync(insertStakeQuery, [
                                        eosId,
                                        amount,
                                        time,
                                        propertyId,
                                        "unstake",
                                        txn_id
                                    ]);
                                    const logData = {
                                        timestamp: new Date().toISOString(),
                                        action: `created for ${propertyId} user spark activity UNSTAKE, spark_amount: ${amount}, start_time: ${time}, eos_id: ${eosId}, build_id: ${propertyId}`
                                    };
                                    existingLogs.push(logData);
                                    console.log(
                                        `created for ${propertyId} user spark activity UNSTAKE, spark_amount: ${amount}, start_time: ${time}, eos_id: ${eosId}, build_id: ${propertyId}`
                                    );
                                }
                            }
                        }
                    }
                    catch (error) {
                        const logData = {
                            timestamp: new Date().toISOString(),
                            action: `Error in Unstake event processing:: ${error}`
                        };
                        existingErrors.push(logData);
                        console.error("Error in Unstake event processing:", error);
                    }
                    console.log("unstake insert", unstake_insert)
                }

                else if (actionName === "a32") {
                    let destory_insert = 0
                    try {
                        const owner_eos_id = action["action_trace"]["act"]["data"]["a54"];
                        const nft_id = action["action_trace"]["act"]["data"]["p115"][0];
                        const time = action["action_trace"]["block_time"];
                        const txn_id = action["action_trace"]["trx_id"];
                        let query = "SELECT * FROM build_activities_all WHERE nft_id =?";
                        const nft_result = await queryAsync(query, [nft_id]);
                        if (nft_result.length > 0) {
                            if (new Date(nft_result[0].build_start_time).getTime() < new Date(time).getTime()) {
                                if (!(nft_result[0].status == 'destroyed')) {
                                    let updateBuildQuery = `UPDATE build_activities_all SET status = ? where nft_id = ?`;
                                    await queryAsync(updateBuildQuery, [
                                        "destroyed",
                                        nft_id.toString(),
                                    ]);
                                    destory_insert++
                                    const logData = {
                                        timestamp: new Date().toISOString(),
                                        action: `Updated for ${nft_id} Destory,  destroy_start_time: ${time}, owner_eos_id: ${owner_eos_id}`
                                    };
                                    existingLogs.push(logData);
                                    console.log(
                                        `Updated for ${nft_id} Destory,  destroy_start_time: ${time}, owner_eos_id: ${owner_eos_id}`
                                    );
                                }
                            }
                        }
                    } catch (error) {
                        const logData = {
                            timestamp: new Date().toISOString(),
                            action: `Error in destroy event processing: ${error}`
                        };
                        existingErrors.push(logData);
                        console.error("Error in destroy event processing:", error);
                    }

                    console.log('Destory insert', destory_insert)
                }

                else if (actionName === "n111") {
                    const playerOne = action["action_trace"]["act"]["data"]["p1"];
                    const playerTwo = action["action_trace"]["act"]["data"]["p2"];
                    const amount = action["action_trace"]["act"]["data"]["p45"].split(" ")[0];
                    const time = action["action_trace"]["block_time"];
                    const txn_id = action["action_trace"]["trx_id"];
                    const tax = action["action_trace"]["act"]["data"]["p134"].split(" ")[0];

                    if (playerTwo == "t244kyn1cc2m") {
                        let deposit_insert = 0
                        let query = "SELECT * FROM transactions WHERE transaction_id =?";
                        const trx_result = await queryAsync(query, [txn_id]);
                        if (trx_result.length == 0) {
                            let query = "SELECT * FROM upland_data WHERE upland_eos_id =? and upland_auth_token is NOT NULL";
                            const db_result = await queryAsync(query, [playerOne]);
                            if (db_result.length > 0) {
                                const insertDepositQuery =
                                    "INSERT INTO transactions (transaction_id, initiated_by, upx_amount, type, source_wallet, destination_wallet, memo, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                                await queryAsync(insertDepositQuery, [
                                    txn_id,
                                    db_result[0].email_address,
                                    parseFloat(amount) + parseFloat(tax),
                                    "deposit",
                                    playerOne,
                                    playerTwo,
                                    "direct",
                                    "completed"
                                ]);
                                const walletUpdateQuery = "UPDATE wallet SET upx_balance = upx_balance + ? where email_address = ?"
                                await queryAsync(walletUpdateQuery, [
                                    parseFloat(amount) - parseFloat(tax),
                                    db_result[0].email_address
                                ]);
                                deposit_insert++;
                            }

                        }
                        console.log('deposit insert', deposit_insert)
                    }
                }
            }


        }
        console.log('Record checked', counter)

        currentPos += data.actions.length;
        console.log('currentPos', currentPos)
        saveLogsToFile(logsFilePath, existingLogs);
        saveLogsToFile(ErrorFilePath, existingErrors);


    } catch (error) {
        const logData = {
            timestamp: new Date().toISOString(),
            action: `Error in cron job: ${error}`
        };
        existingErrors.push(logData);
        saveLogsToFile(logsFilePath, existingLogs);
        saveLogsToFile(ErrorFilePath, existingErrors);

        console.error("Error in cron job:", error);
    }
});

