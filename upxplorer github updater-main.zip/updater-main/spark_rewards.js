const cron = require("node-cron");
const util = require("util");
const mysql = require("mysql");

const pool = mysql.createPool({
    host: 'mysql-161810-0.cloudclusters.net',
    user: 'admin',
    password: 'iKl3KA5b',
    database: 'upxplorer',
    port: 19878
});

const queryAsync = util.promisify(pool.query).bind(pool);


async function getMinutes(input_time_one, input_time_two) {
    return (input_time_one.getTime() - input_time_two.getTime()) / 60000
}

async function getCurrentTimeUTC() {
    // Get current time in UTC
    var current_time_utc = new Date();
    var utcYear = current_time_utc.getUTCFullYear();
    var utcMonth = current_time_utc.getUTCMonth();
    var utcDay = current_time_utc.getUTCDate();
    var utcHour = current_time_utc.getUTCHours();
    var utcMinute = current_time_utc.getUTCMinutes();
    var utcSecond = current_time_utc.getUTCSeconds();
    var utcMillisecond = current_time_utc.getUTCMilliseconds();

    return new Date(Date.UTC(utcYear, utcMonth, utcDay, utcHour, utcMinute, utcSecond, utcMillisecond));
}

async function sparkContractRewards() {
    try {
        let query = "SELECT * FROM spark_contracts WHERE status = ?";
        const spark_contracts = await queryAsync(query, ["in progress"]);

        if (spark_contracts.length > 0) {
            let current_time = new Date();
            for (let i = 0; i < spark_contracts.length; i++) {
                let query = "SELECT * FROM build_activities_all WHERE nft_id = ?";
                const build_details = await queryAsync(query, [spark_contracts[i].build_id]);
                if (build_details[0].status == "processing") {
                    // time since last rewarded
                    console.log("time since last rewarded for contract", spark_contracts[i].spark_contract_id, "is", await getMinutes(current_time, spark_contracts[i].last_rewarded))

                    // read contract
                    let totalRewardedAmount = 0;
                    if (await getMinutes(current_time, spark_contracts[i].last_rewarded) > 60) {
                        // if its more than 60 mins since last rewarded get all the spark activity on the build
                        let query = "SELECT eos_id, JSON_ARRAYAGG(JSON_ARRAY(`spark_amount`,`start_time`,`type`)) AS sparkActivity FROM `user_spark_activity` WHERE `build_id`=? group by eos_id";
                        const user_spark_activity = await queryAsync(query, [spark_contracts[i].build_id]);


                        // loop through all the eos account activity
                        for (let j = 0; j < user_spark_activity.length; j++) {
                            const element = user_spark_activity[j];

                            // check if user is connect to the platform
                            let query = "SELECT email_address FROM `upland_data` WHERE `upland_eos_id`=?";
                            const userUplandData = await queryAsync(query, [element.eos_id]);

                            if (userUplandData.length > 0) {

                                let totalStakedHoursSinceUpdate = 0;
                                let totalUnstakedHoursSinceUpdate = 0;
                                const sparkActivity = JSON.parse(element.sparkActivity);

                                for (let k = 0; k < sparkActivity.length; k++) {
                                    // start checking spark activity
                                    const userSparkActivity = sparkActivity[k];
                                    userSparkActivity[1] = new Date(userSparkActivity[1])
                                    if (userSparkActivity[2] == "stake") {
                                        // if user staked after last rewarded time
                                        if (await getMinutes(spark_contracts[i].last_rewarded, userSparkActivity[1]) < 60) {
                                            // get total minutes staked convert that into hours and multiply with the amount of spark staked
                                            totalStakedHoursSinceUpdate = totalStakedHoursSinceUpdate + (await getMinutes(current_time, userSparkActivity[1]) / 60 * parseFloat(userSparkActivity[0]))
                                        } else {
                                            totalStakedHoursSinceUpdate = totalStakedHoursSinceUpdate + (await getMinutes(current_time, spark_contracts[i].last_rewarded) / 60 * parseFloat(userSparkActivity[0]))
                                        }
                                    }
                                    else {
                                        if (await getMinutes(spark_contracts[i].last_rewarded, userSparkActivity[1]) < 60) {
                                            totalUnstakedHoursSinceUpdate = totalUnstakedHoursSinceUpdate + (await getMinutes(current_time, userSparkActivity[1]) / 60 * parseFloat(userSparkActivity[0]))
                                        } else {
                                            totalUnstakedHoursSinceUpdate = totalUnstakedHoursSinceUpdate + (await getMinutes(current_time, spark_contracts[i].last_rewarded) / 60 * parseFloat(userSparkActivity[0]))
                                        }
                                    }
                                }
                                // Calculate the reward amount
                                if (parseFloat(totalStakedHoursSinceUpdate - totalUnstakedHoursSinceUpdate) > 0) {
                                    const reward = parseFloat(totalStakedHoursSinceUpdate - totalUnstakedHoursSinceUpdate) * parseFloat(spark_contracts[i].upx_hr)
                                    totalRewardedAmount = totalRewardedAmount + reward

                                    let old_query = "SELECT * FROM wallet WHERE email_address= ?";
                                    const old_wallet_data = await queryAsync(old_query, [userUplandData[0].email_address]);
                                    let updateWalletQuery = `UPDATE wallet SET upx_balance = upx_balance + ? WHERE email_address = ?`;
                                    await queryAsync(updateWalletQuery, [
                                        reward,
                                        userUplandData[0].email_address,
                                    ]);
                                    let new_query = "SELECT * FROM wallet WHERE email_address= ?";
                                    const new_wallet_data = await queryAsync(new_query, [userUplandData[0].email_address]);

                                    //add entry in hourly rewards
                                    const insertQuery =
                                        "INSERT INTO hourly_rewards (spark_contract_id, reward_amount, user_email, rewarded_time, user_balance, spark_hours, updated_user_balance, unix_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                                    await queryAsync(insertQuery, [
                                        spark_contracts[i]?.spark_contract_id,
                                        reward,
                                        userUplandData[0].email_address,
                                        current_time,
                                        parseFloat(old_wallet_data[0].upx_balance),
                                        totalStakedHoursSinceUpdate - totalUnstakedHoursSinceUpdate,
                                        parseFloat(new_wallet_data[0].upx_balance),
                                        Date.now()

                                    ]);
                                    console.log("Rewarded: Contract ", spark_contracts[i].spark_contract_id, "User:", userUplandData[0].email_address, "Spark hours:", totalStakedHoursSinceUpdate - totalUnstakedHoursSinceUpdate, "reward amount", reward)
                                }

                            }
                        }
                        const remaining_upx_pool = parseFloat(spark_contracts[i]?.remaining_upx_pool) - parseFloat(totalRewardedAmount);
                        // update last rewarded time and remaining pool 
                        let updateSparkContractstQuery = `UPDATE spark_contracts SET last_rewarded = ?, remaining_upx_pool = ? WHERE spark_contract_id = ?`;
                        await queryAsync(updateSparkContractstQuery, [
                            current_time,
                            remaining_upx_pool,
                            spark_contracts[i]?.spark_contract_id
                        ]);
                    }

                }
                else {
                    // time since last rewarded
                    console.log("time since last rewarded for contract", spark_contracts[i].spark_contract_id, "is", await getMinutes(current_time, spark_contracts[i].last_rewarded))

                    // read contract
                    let totalRewardedAmount = 0;
                    // if its more than 60 mins since last rewarded get all the spark activity on the build
                    let query = "SELECT eos_id, JSON_ARRAYAGG(JSON_ARRAY(`spark_amount`,`start_time`,`type`)) AS sparkActivity FROM `user_spark_activity` WHERE `build_id`=? group by eos_id";
                    const user_spark_activity = await queryAsync(query, [spark_contracts[i].build_id]);


                    // loop through all the eos account activity
                    for (let j = 0; j < user_spark_activity.length; j++) {
                        const element = user_spark_activity[j];

                        // check if user is connect to the platform
                        let query = "SELECT email_address FROM `upland_data` WHERE `upland_eos_id`=?";
                        const userUplandData = await queryAsync(query, [element.eos_id]);

                        if (userUplandData.length > 0) {

                            let totalStakedHoursSinceUpdate = 0;
                            let totalUnstakedHoursSinceUpdate = 0;
                            const sparkActivity = JSON.parse(element.sparkActivity);

                            for (let k = 0; k < sparkActivity.length; k++) {
                                // start checking spark activity
                                const userSparkActivity = sparkActivity[k];
                                userSparkActivity[1] = new Date(userSparkActivity[1])
                                if (userSparkActivity[2] == "stake") {
                                    // if user staked after last rewarded time
                                    if (await getMinutes(spark_contracts[i].last_rewarded, userSparkActivity[1]) < 60) {
                                        // get total minutes staked convert that into hours and multiply with the amount of spark staked
                                        totalStakedHoursSinceUpdate = totalStakedHoursSinceUpdate + (await getMinutes(current_time, userSparkActivity[1]) / 60 * parseFloat(userSparkActivity[0]))
                                    } else {
                                        totalStakedHoursSinceUpdate = totalStakedHoursSinceUpdate + (await getMinutes(current_time, spark_contracts[i].last_rewarded) / 60 * parseFloat(userSparkActivity[0]))
                                    }
                                }
                                else {
                                    if (await getMinutes(spark_contracts[i].last_rewarded, userSparkActivity[1]) < 60) {
                                        totalUnstakedHoursSinceUpdate = totalUnstakedHoursSinceUpdate + (await getMinutes(current_time, userSparkActivity[1]) / 60 * parseFloat(userSparkActivity[0]))
                                    } else {
                                        totalUnstakedHoursSinceUpdate = totalUnstakedHoursSinceUpdate + (await getMinutes(current_time, spark_contracts[i].last_rewarded) / 60 * parseFloat(userSparkActivity[0]))
                                    }
                                }
                            }
                            // Calculate the reward amount
                            const reward = parseFloat(totalStakedHoursSinceUpdate - totalUnstakedHoursSinceUpdate) * parseFloat(spark_contracts[i].upx_hr)
                            totalRewardedAmount = totalRewardedAmount + reward
                            if (parseFloat(totalStakedHoursSinceUpdate - totalUnstakedHoursSinceUpdate) > 0) {
                                const reward = parseFloat(totalStakedHoursSinceUpdate - totalUnstakedHoursSinceUpdate) * parseFloat(spark_contracts[i].upx_hr)
                                totalRewardedAmount = totalRewardedAmount + reward

                                let old_query = "SELECT * FROM wallet WHERE email_address= ?";
                                const old_wallet_data = await queryAsync(old_query, [userUplandData[0].email_address]);
                                let updateWalletQuery = `UPDATE wallet SET upx_balance = upx_balance + ? WHERE email_address = ?`;
                                await queryAsync(updateWalletQuery, [
                                    reward,
                                    userUplandData[0].email_address,
                                ]);
                                let new_query = "SELECT * FROM wallet WHERE email_address= ?";
                                const new_wallet_data = await queryAsync(new_query, [userUplandData[0].email_address]);

                                //add entry in hourly rewards
                                const insertQuery =
                                    "INSERT INTO hourly_rewards (spark_contract_id, reward_amount, user_email, rewarded_time, user_balance, spark_hours, updated_user_balance, unix_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                                await queryAsync(insertQuery, [
                                    spark_contracts[i]?.spark_contract_id,
                                    reward,
                                    userUplandData[0].email_address,
                                    current_time,
                                    parseFloat(old_wallet_data[0].upx_balance),
                                    totalStakedHoursSinceUpdate - totalUnstakedHoursSinceUpdate,
                                    parseFloat(new_wallet_data[0].upx_balance),
                                    Date.now()
                                ]);

                                console.log("Rewarded: Contract ", spark_contracts[i].spark_contract_id, "User:", userUplandData[0].email_address, "Spark hours:", totalStakedHoursSinceUpdate - totalUnstakedHoursSinceUpdate, "reward amount", reward)
                            }

                        }
                    }
                    const remaining_upx_pool = parseFloat(spark_contracts[i]?.remaining_upx_pool) - parseFloat(totalRewardedAmount);
                    // update last rewarded time and remaining pool 
                    let updateSparkContractstQuery = `UPDATE spark_contracts SET last_rewarded = ?, remaining_upx_pool = ?, status = ? WHERE spark_contract_id = ?`;
                    await queryAsync(updateSparkContractstQuery, [
                        current_time,
                        0,
                        "completed",
                        spark_contracts[i]?.spark_contract_id
                    ]);
                    // refund users extra amount
                    if (remaining_upx_pool > 0) {

                        const insertDepositQuery =
                            "INSERT INTO transactions (transaction_id, initiated_by, upx_amount, type, source_wallet, destination_wallet, memo, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                        const txnId = "destory-refund-" + spark_contracts[i]?.spark_contract_id
                        await queryAsync(insertDepositQuery, [
                            txnId,
                            spark_contracts[i]?.email_address,
                            remaining_upx_pool,
                            "refund",
                            "upxplorer",
                            "---",
                            "UPX Pool refunded",
                            "completed"
                        ]);
                        // let query = "SELECT * FROM wallet WHERE email_address= ?";
                        let updateWalletQuery = `UPDATE wallet SET upx_balance = upx_balance + ? WHERE email_address = ?`;
                        await queryAsync(updateWalletQuery, [
                            remaining_upx_pool,
                            spark_contracts[i]?.email_address
                        ]);
                        console.log("REFUNDED: Contract ", spark_contracts[i].spark_contract_id, "User:", spark_contracts[i]?.email_address, "refund amount", remaining_upx_pool)

                    }

                }

            }


        }
    } catch (error) {
        console.log(error)
    }
}

cron.schedule("*/5 * * * *", async () => {

    await sparkContractRewards()
});
